# 24do

This is a reminder app for iOS. Due to insufficient features, it was not approved to the App Store. You can read the full story [here](https://medium.com/@kenzonawa/my-first-app-didnt-make-it-to-the-app-store-600820cf66a5).

## Installation

Download the repository and run 24do.xcworkspace. XCode should load everything and you can run it either on the device simulator or transfer it to your phone. 
