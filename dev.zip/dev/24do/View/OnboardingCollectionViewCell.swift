//
//  OnboardingCollectionViewCell.swift
//  24do
//
//  Created by user1 on 10/05/19.
//  Copyright © 2019 Victor Kenzo Nawa. All rights reserved.
//

import UIKit

class OnboardingCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lbDes: UILabel!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var img: UIImageView!
}
