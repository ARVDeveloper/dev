//
//  TimelineTableViewController.swift
//  TimelineTableViewCell
//
//  Created by Zheng-Xiang Ke on 2016/10/20.
//  Copyright © 2016年 Zheng-Xiang Ke. All rights reserved.
//

import UIKit
import TimelineTableViewCell
import CoreData

class TimelineTableViewController: UITableViewController {
    var tasks: [Task] = []
    // TimelinePoint, Timeline back color, title, description, lineInfo, thumbnail, illustration
    var data  = [Int: [(TimelinePoint, UIColor, String, String, String?, String?, String?)]]()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        let timelineTableViewCellNib = UINib(nibName: "TimelineTableViewCell", bundle: Bundle(for: TimelineTableViewCell.self))
        self.tableView.register(timelineTableViewCellNib, forCellReuseIdentifier: "TimelineTableViewCell")
      
    }
   override func viewWillAppear(_ animated: Bool) {
        self.getData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return tasks.count
    }
    
    

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimelineTableViewCell", for: indexPath) as! TimelineTableViewCell

        // Configure the cell...

        var timelineFrontColor = UIColor.clear
        if (indexPath.row > 0) {
            timelineFrontColor = UIColor.green
        }
        cell.timelinePoint = TimelinePoint()
        cell.timeline.frontColor = timelineFrontColor
        cell.timeline.backColor = UIColor.black
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"
        var dateString = dateFormatter.string(from: tasks[indexPath.row].notificationTime!)
        if dateString.hasPrefix("0") {
            dateString.remove(at: dateString.startIndex)
        }
       
        cell.titleLabel.text = dateString
        cell.descriptionLabel.text = tasks[indexPath.row].name
        cell.lineInfoLabel.text = nil
        cell.thumbnailImageView.image = nil
        cell.illustrationImageView.image = UIImage(named: "timeline")
   
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
    }

    func getData(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        do{
            let fec: NSFetchRequest = Task.fetchRequest()
            let sortDescriptor = NSSortDescriptor(key: "notificationTime", ascending: true)
            fec.sortDescriptors = [sortDescriptor]
            tasks = try context.fetch(fec)
        }
        catch{
            print("Fetching failed.")
        }
        self.tableView.reloadData()
    }
    
}
