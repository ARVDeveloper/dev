//
//  TabBar.swift
//  24do
//
//  Created by user1 on 10/05/19.
//  Copyright © 2019 Victor Kenzo Nawa. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override func awakeFromNib() {
        self.navigationItem.setHidesBackButton(true, animated:true);
    }

}
