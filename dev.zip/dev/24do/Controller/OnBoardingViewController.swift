//
//  OnBoardingViewController.swift
//  24do
//
//  Created by user1 on 10/05/19.
//  Copyright © 2019 Victor Kenzo Nawa. All rights reserved.
//

import UIKit

class OnBoardingViewController: UIViewController {
  var arrTitle = ["Engage","Med Reminder","Track"]
     var arrSubTitle = ["Engage your self by meaning full task.","Make reminder ","notify when complete"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true);
         self.title = "24do"
    }
    @IBAction func btnSkip(_ sender: Any) {
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "TabBarController" ) as! TabBarController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

    

}
extension OnBoardingViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnboardingCollectionViewCell", for: indexPath) as! OnboardingCollectionViewCell
        cell.lblTitle.text = self.arrTitle[indexPath.item]
        cell.lbDes.text = self.arrSubTitle[indexPath.item]
        cell.img.image = UIImage(named: "0\(indexPath.item + 1 )")
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
}
